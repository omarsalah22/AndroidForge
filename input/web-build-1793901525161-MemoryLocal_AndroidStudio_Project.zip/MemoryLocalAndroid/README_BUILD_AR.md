# مشروع Android Studio — ذاكرني

هذا مشروع Android قابل للفتح في Android Studio، ويغلف النموذج الأولي المحلي داخل WebView.
**ليس ملف APK مُجمّعاً**؛ يلزم Android SDK وGradle لإنتاج APK.

## بناء APK
1. افتح مجلد `MemoryLocal` في Android Studio.
2. انتظر Gradle Sync مع تثبيت Android SDK Platform 35.
3. من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. ستجد الملف عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## تنبيه حول المرحلة الحالية
هذه نسخة MVP أولية: البيانات تحفظ داخل WebView localStorage على الجهاز. لا يوجد تسجيل دخول أو اتصال بخدمات سحابية أو صلاحية إنترنت. الميزات المتقدمة (قاعدة Room، المرفقات، خرائط فعلية، مؤقت خلفي، مهام متداخلة) لم تكتمل بعد.
